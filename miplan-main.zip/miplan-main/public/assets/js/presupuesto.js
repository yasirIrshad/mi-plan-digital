var presupuesto = new Vue({
    el: '#presupuesto',
    data: () => ({
        isLoading: false,
    }),   
    created() {
    }, 
    methods: {
        enviarPresupuesto(){
            
        }
    }
});
