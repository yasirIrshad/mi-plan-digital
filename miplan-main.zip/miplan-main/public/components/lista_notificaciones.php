<div class="card col-md-3 col-sm-12 col-xs-12" id="notiListCard" style="display: none; padding: 2px!important; margin-bottom: 0;">
    <div class="card-body d-flex justify-content-between" style="padding: 0 0 0 10px; border-bottom: 1px solid gray">
        <h5 style="font-size: 14px;">Notificationes <span id="notiCount"></span></h5>
        <button type="button" style="border: transparent; background: white" class="closeNoti mr-2 d-flex align-items-center">
            <span style="font-size: 20px;" aria-hidden="true">&times;</span>
        </button>
    </div>

    <div id="noti-list" style="max-height: 210px; overflow-y:auto; margin-bottom: 4px">
       
       
    </div>
    <a href="javascript:void(0);" class="dropdown-item notify-all hoverNotifications" style="display: none; padding-top: 0px">
        <hr style="margin: 0 0 7px 0">
        View All
    </a>
    
</div> 

