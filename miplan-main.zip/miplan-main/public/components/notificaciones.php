<div class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-menu-lg dropdown-menu-animated" style="width: 350px;">
    <!-- item-->
    <div class="dropdown-item noti-title">
        <h5>Notificationes <span id="notiCount2"></span></h5>
    </div>

    <div class="noti" style="max-height: 220px; overflow-y:auto">
        <!-- item-->
    </div>
    

    <!-- All-->
    <a href="javascript:void(0);" class="dropdown-item notify-all hoverNotifications" style="display: none; padding-top: 0px">
        <hr style="margin: 0 0 7px 0">
        View All
    </a>

</div>