<!-- firebase -->
<script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-app.js"></script>

<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-functions.js"></script>


<!-- firebase credentials -->

<script>
  var firebaseConfig = {
    apiKey: "AIzaSyAKQ9WiN5gUoShtyDW9U3d_xJ68-XTtnCM",
    authDomain: "kb-nlmi.firebaseapp.com",
    databaseURL: "https://kb-nlmi-default-rtdb.firebaseio.com",
    projectId: "kb-nlmi",
    storageBucket: "kb-nlmi.appspot.com",
    messagingSenderId: "20929144142",
    appId: "1:20929144142:web:ab9c17f7bdec7d158eea1f"
  }

  firebase.initializeApp(this.firebaseConfig);

  firebase.auth().onAuthStateChanged(function (user) {
    if (!user) {
      window.location.href = "../login.php";
    }
  });
</script>




<!-- Vue js cdn -->
<!-- <script src="https://cdn.jsdelivr.net/npm/vue@2"></script> -->


<!-- jQuery  -->
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/modernizr.min.js"></script>
<script src="../assets/js/detect.js"></script>
<script src="../assets/js/fastclick.js"></script>
<script src="../assets/js/jquery.slimscroll.js"></script>
<script src="../assets/js/jquery.blockUI.js"></script>
<script src="../assets/js/waves.js"></script>
<script src="../assets/js/jquery.nicescroll.js"></script>
<script src="../assets/js/jquery.scrollTo.min.js"></script>

<!-- sweet alert js -->
<script src="../plugins/sweetalert2/sweetalert2.all.min.js"></script>

<script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-app.js"></script>

<!-- Add Firebase products that you want to use -->
<script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-functions.js"></script>

<!-- App js -->
<script src="../assets/js/notificaciones.js"></script>
<script src="../assets/js/avatars.js"></script>
<script src="../assets/js/app.js"></script>

<script src="../assets/js/account.js"></script>

<!-- App Auth js -->
<script src="../assets/js/guard.login.js"></script>
<script src="../assets/js/logout.js"></script>