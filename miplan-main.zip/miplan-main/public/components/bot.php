<div 
    id="botcopy-embedder-d7lcfheammjct" 
    class="botcopy-embedder-d7lcfheammjct" 
    data-botId="6023c4394917ac0009a83d3b">

    <script type="text/javascript">
        var s = document.createElement('script');
        s.type = 'text/javascript';
        s.async = true;
        s.src = 'https://widget.botcopy.com/js/injection.js';
        document.getElementById('botcopy-embedder-d7lcfheammjct').appendChild(s);

        const token = localStorage.getItem('token')
        // Botcopy.setESParameters({
        //     webhookHeaders: { acceesToken: token },            
        // })
        
    </script>

</div>